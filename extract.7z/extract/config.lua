Config = {}
Config.MaxActiveExtracts = 4
Config.ExtractTime = 15

Config.Marker = {
    enabled = true,
    type = 25,
    scale = vec3(1.8, 1.8, 1.0),
    color = {r = 60, g = 200, b = 60, a = 180},
    bobUpAndDown = false
}
Config.Rotation = {
    minMinutes = 30,
    maxMinutes = 60,
    changeProbability = 0.65
}
Config.Keybind = {
    command = 'toggleExtracts',
    default = 'NUMPAD1',   --THIS CAN BE CHANGED TO ANY KEYBIND
    description = 'Toggle extract list'
}
Config.Extracts = {
    {
        id = 'EXIT01',
        label = 'Path to Shoreline',
        center = vec3(-1598.3, 4735.7, 52.3),
        radius = 2.8,
        dest = vec4(1730.2, 3299.6, 41.1, 75.0)
    },
    {
        id = 'EXIT02',
        label = 'Old Bridge',
        center = vec3(1732.5, 6422.4, 34.0),
        radius = 3.0,
        dest = vec4(2371.9, 3165.5, 48.2, 140.0)
    },
    {
        id = 'EXIT03',
        label = 'Railroad to Port',
        center = vec3(2614.1, 2826.3, 35.0),
        radius = 3.2,
        dest = vec4(-1082.9, -2868.9, 13.9, 330.0)
    },
    {
        id = 'EXIT04',
        label = 'RUAF Roadblock',
        center = vec3(164.0, 6624.3, 31.7),
        radius = 2.5,
        dest = vec4(-1044.8, 4907.9, 211.0, 12.0)
    },
}
