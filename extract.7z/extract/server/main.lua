local extracts = Config.Extracts
local active = {}

local function selectActive()
    local pool = {}
    for i = 1, #extracts do pool[i] = i end
    for i = #pool, 2, -1 do
        local j = math.random(i)
        pool[i], pool[j] = pool[j], pool[i]
    end
    local count = math.min(Config.MaxActiveExtracts, #extracts)
    local out = {}
    for i = 1, count do out[#out+1] = pool[i] end
    return out
end

local function broadcastActive()
    GlobalState.ActiveExtracts = active
end

local function scheduleRotation()
    local mins = math.random(Config.Rotation.minMinutes, Config.Rotation.maxMinutes)
    SetTimeout(mins * 60 * 1000, function()
        if math.random() < Config.Rotation.changeProbability then
            active = selectActive()
            broadcastActive()
        end
        scheduleRotation()
    end)
end

AddEventHandler('onResourceStart', function(res)
    if res ~= GetCurrentResourceName() then return end
    math.randomseed(GetGameTimer())
    active = selectActive()
    broadcastActive()
    scheduleRotation()
end)


RegisterNetEvent('tsrkov:server:completeExtract', function(idx)
    local src = source
    local list = GlobalState.ActiveExtracts or {}
    local ok
    for _, i in ipairs(list) do if i == idx then ok = true break end end
    if not ok then return end
    local e = extracts[idx]
    if not e then return end
    local ped = GetPlayerPed(src)
    if not ped or ped == 0 then return end
    SetEntityCoords(ped, e.dest.x, e.dest.y, e.dest.z, false, false, false, false)
    SetEntityHeading(ped, e.dest.w or 0.0)
    TriggerClientEvent('tsrkov:client:extracted', src, idx)
end)

RegisterNetEvent('tsrkov:server:requestActive', function()
    TriggerClientEvent('tsrkov:client:setActive', source, active)
end)
