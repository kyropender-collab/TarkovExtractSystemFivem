let bar = document.getElementById('extractBar');
let barText = document.getElementById('extractText');
let barFill = document.getElementById('barFill');
let list = document.getElementById('extractList');

let extractInfo = document.createElement('div');
extractInfo.id = "extractInfo";
extractInfo.classList.add("hidden");
document.body.appendChild(extractInfo);

let barMax = 15;
let extractTimer = null;

window.addEventListener('message', (e) => {
  const data = e.data || {};
  switch (data.action) {
    case 'showBar':
      if (data.show) {
        bar.style.display = "flex";
        bar.classList.remove("hidden");
        barMax = data.max || barMax;
        updateBar(barMax);
      } else {
        hideBar();
      }
      break;

    case 'barTick':
      updateBar(data.seconds);
      break;

    case 'setList':
      setList(data.items || []);
      if (data.show) {
        list.style.display = "flex";
        list.classList.remove("hidden");

        if (extractTimer) clearTimeout(extractTimer);
        extractTimer = setTimeout(() => {
          list.style.display = "none";
          list.classList.add("hidden");
        }, 10000);
      } else {
        list.style.display = "none";
        list.classList.add("hidden");
      }
      break;

    case 'showExtractInfo':
      showExtractInfo(data.label, data.time);
      break;

    case 'updateExtractInfo':
      updateExtractInfo(data.time);
      break;

    case 'hideExtractInfo':
    case 'cancelExtract':
      hideBar();
      hideExtractInfo();
      break;
  }
});
function updateBar(secondsLeft) {
  secondsLeft = Math.max(0, secondsLeft|0);
  barText.textContent = `Extraction in ${secondsLeft}`;
  barFill.style.width = "100%";
}

function hideBar() {
  bar.style.display = "none";
  bar.classList.add("hidden");
  barText.textContent = "";
  barFill.style.width = "0%";
}

function setList(items) {
  list.innerHTML = '';
  items.forEach((it, idx) => {
    const row = document.createElement('div');
    row.className = 'exRow';
    row.innerHTML = `
      <div class="left">
        <span class="pill">EXIT${String(idx+1).padStart(2,'0')}</span>
        <span>${it.label}</span>
      </div>
      <div class="right">${it.available ? "AVAILABLE" : "LOCKED"}</div>
    `;
    list.appendChild(row);
  });
}
function showExtractInfo(label, time) {
  extractInfo.innerHTML = `
    <div class="infoBox">
      <span class="title">Stay in the extraction point</span>
      <div class="row">
        <span class="pill">EXFIL</span>
        <span>${label}</span>
        <span class="time">${time || ""}s</span>
      </div>
    </div>
  `;
  extractInfo.style.display = "flex";
  extractInfo.classList.remove("hidden");
}

function updateExtractInfo(time) {
  const timeEl = extractInfo.querySelector('.time');
  if (timeEl) timeEl.textContent = `${time || ""}s`;
}

function hideExtractInfo() {
  extractInfo.style.display = "none";
  extractInfo.classList.add("hidden");
  extractInfo.innerHTML = "";
}
