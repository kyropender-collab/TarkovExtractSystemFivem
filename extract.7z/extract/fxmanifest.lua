fx_version 'cerulean'
game 'gta5'

lua54 'yes'

author 'FiveM Lua Pro'
description 'Tarkov-style extractions (server-synced)'
-- DO NOT TOUCH ANYTHING BELOW IF YOU DONT KNOW WHAT YOU ARE DOING
shared_scripts {
    '@ox_lib/init.lua',
    'config.lua'
}

client_scripts {
    '@PolyZone/client.lua',
    '@PolyZone/BoxZone.lua',
    '@PolyZone/CircleZone.lua',
    'client/main.lua'
}

server_scripts {
    'server/main.lua'
}

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/app.js',
    'html/runningman.png'
}
