local zones = {}               -- all PolyZone circle zones by index
local active = {}              -- list of active extract indices (mirrors server)
local insideIdx = nil          -- which extract index the player is inside
local extracting = false
local extractTimer = 0

-- NUI helpers
local function ui_showBar(show, max)
    SendNUIMessage({ action = 'showBar', show = show, max = max })
end
local function ui_updateBar(secondsLeft)
    SendNUIMessage({ action = 'barTick', seconds = secondsLeft })
end
local function ui_setList(items, visible)
    SendNUIMessage({ action = 'setList', items = items, show = visible })
end

-- list toggle state
local listVisible = false

-- hide everything at resource start
AddEventHandler('onClientResourceStart', function(res)
    if res == GetCurrentResourceName() then
        Wait(500)
        ui_showBar(false)
        ui_setList({}, false)
        SendNUIMessage({ action = 'cancelExtractInfo' }) -- ?? ensure info panel hidden
    end
end)

-- build all zones once
CreateThread(function()
    for i, e in ipairs(Config.Extracts) do
        local z = CircleZone:Create(e.center, e.radius, { name = e.id, useZ = true, debugPoly = false })
        zones[i] = z
        z:onPlayerInOut(function(isInside)
            if not table.contains(active, i) then return end
            if isInside then
                insideIdx = i

                -- start extraction countdown
                if not extracting then
                    extracting = true
                    extractTimer = Config.ExtractTime
                    ui_showBar(true, Config.ExtractTime) -- show bar ONLY inside zone with correct max
                    
                    -- ?? Show extract info panel
                    SendNUIMessage({
                        action = 'showExtractInfo',
                        id = e.id,
                        label = e.label,
                        time = extractTimer
                    })

                    while extracting and insideIdx == i and extractTimer > 0 do
                        ui_updateBar(extractTimer)
                        -- update info UI each tick
                        SendNUIMessage({ action = 'updateExtractInfo', time = extractTimer })

                        -- manual distance check as failsafe
                        local ped = PlayerPedId()
                        local pos = GetEntityCoords(ped)
                        local dist = #(pos - vector3(e.center.x, e.center.y, e.center.z))
                        if dist > e.radius then
                            insideIdx = nil
                            extracting = false
                            ui_showBar(false)
                            SendNUIMessage({ action = 'cancelExtractInfo' }) -- ?? hide info
                            break
                        end

                        Wait(1000)
                        extractTimer -= 1
                    end

                    if extracting and insideIdx == i and extractTimer <= 0 then
                        TriggerServerEvent('tsrkov:server:completeExtract', i)
                    end

                    ui_showBar(false)      -- always hide when done
                    SendNUIMessage({ action = 'cancelExtractInfo' }) -- ?? hide info
                    extracting = false
                end
            else
                if insideIdx == i then
                    insideIdx = nil
                    extracting = false
                    ui_showBar(false)      -- hide if leave zone
                    SendNUIMessage({ action = 'cancelExtractInfo' }) -- ?? hide info
                end
            end
        end)
    end
end)

-- util: contains
function table.contains(t, v)
    for _, x in pairs(t) do if x == v then return true end end
end

-- reflect server active list
local function refreshList()
    local items = {}
    for _, idx in ipairs(active) do
        local e = Config.Extracts[idx]
        items[#items+1] = { id = e.id, label = e.label }
    end
    ui_setList(items, listVisible)
end

-- GlobalState bridge (auto-sync)
CreateThread(function()
    while true do
        local gs = GlobalState.ActiveExtracts
        if gs and (#gs ~= #active) then
            active = gs
            refreshList()
        end
        Wait(1000)
    end
end)

-- event push from server (immediate)
RegisterNetEvent('tsrkov:client:setActive', function(newActive)
    active = newActive or {}
    refreshList()
end)

-- announce completion
RegisterNetEvent('tsrkov:client:extracted', function(idx)
    ui_showBar(false)   -- make 100% sure bar hides
    SendNUIMessage({ action = 'cancelExtractInfo' }) -- ?? hide info
    extracting = false
    insideIdx = nil
    if lib and lib.notify then
        lib.notify({ title = 'Extraction', description = ('Extracted via %s'):format(Config.Extracts[idx].label), type = 'success' })
    end
end)

-- keybind to toggle the list
RegisterCommand(Config.Keybind.command, function()
    listVisible = not listVisible
    refreshList()
end, false)

RegisterKeyMapping(Config.Keybind.command, Config.Keybind.description, 'keyboard', Config.Keybind.default)
